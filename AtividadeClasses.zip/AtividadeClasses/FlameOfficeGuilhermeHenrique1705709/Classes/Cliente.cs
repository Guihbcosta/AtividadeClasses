﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlameOfficeGuilhermeHenrique1705709.Classes
{
    public class Cliente : Usuario
    {

        public int CPF { get; set; }
    }
}
