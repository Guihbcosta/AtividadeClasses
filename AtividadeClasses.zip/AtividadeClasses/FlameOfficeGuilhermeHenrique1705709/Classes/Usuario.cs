﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlameOfficeGuilhermeHenrique1705709.Classes
{
    public class Usuario : Login
    {

        public string nome { get; set; }

        public List<object> GerarLista()
        {

            List<object> listaUsuario = new List<object>();
            return listaUsuario;
        }
    }
}
